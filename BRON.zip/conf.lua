function love.conf(t)
	t.title = "Bridge"
	t.window.width = 800
	t.window.height = 600

end